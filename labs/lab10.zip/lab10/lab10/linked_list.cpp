#include "linked_list.h"

int Linked_List::get_length() {
	// note: there is no set_length(unsigned int) (the reasoning should be intuitive)
	// Your code goes here:

	return -1;
}

void Linked_List::print(){
	// output a list of all integers contained within the list
	// Your code goes here:
	cout << "\n";
	return;
}

void Linked_List::clear(){
	// delete the entire list (remove all nodes and reset length to 0)
	// Your code goes here:

	return;
}

void Linked_List::push_front(int val){
	// insert a new value at the front of the list 
	// Your code goes here:

	return;
}

void Linked_List::pop_front(){
	// remove the node at the front of the list
	// Your code goes here:

	return;
}
