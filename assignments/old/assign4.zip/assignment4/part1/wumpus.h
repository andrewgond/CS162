#ifndef WUMPUS_H
#define WUMPUS_H 

//Wumpus Interface

#endif