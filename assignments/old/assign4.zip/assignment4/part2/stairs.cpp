int ways_to_top(int n) {
	// YOUR CODE GOES HERE
}
