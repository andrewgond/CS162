#include "flight.h"

using namespace std;

Flight::Flight() {
	
}

Flight::~Flight(){
	
}


void Flight::populate_flight(ifstream& fin) {
	//Your code goes here:
	
	return;
}

void Flight::print_flight() {
	//Your code goes here:

	return;
}




