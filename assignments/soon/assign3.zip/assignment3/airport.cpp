#include "airport.h"

using namespace std;

Airport::Airport() {
	
}

Airport::~Airport() {
	
}

void Airport::populate_airport(ifstream& fin){
	//Your code goes here:
	
	return; 
}


void Airport::add_a_flight(Flight& p){
	//Your code goes here:
	
	return; 
}

Flight Airport::remove_a_flight(int idx){
	//Your code goes here:
	
	return Flight();
}

void Airport::print_airport() {
	//Your code goes here:
	
	return; 
}

