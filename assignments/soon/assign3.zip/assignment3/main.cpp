#include <iostream>
#include "manager.h"

using namespace std;

int main()
{
	Manager m;
	m.run();
	return 0;
}