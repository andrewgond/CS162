#include "event.h"

#include <iostream>

using namespace std;

//Event Implementation
char Event::get_debug_symbol() const{
    return this->debug_symbol;
}